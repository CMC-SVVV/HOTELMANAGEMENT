<?php
session_start();
$d = mysqli_connect('localhost','root','','registration');
 if(isset($_POST['s0']))
 {
    $fname = mysqli_real_escape_string($d,$_POST['F']);
    $lname = mysqli_real_escape_string($d,$_POST['L']);
    $Mobile = mysqli_real_escape_string($d,$_POST['M']);
    $checkin = mysqli_real_escape_string($d,$_POST['Ci']);
    $co = mysqli_real_escape_string($d,$_POST['Co']);
    $Room = mysqli_real_escape_string($d,$_POST['RoomType']);
    $Adult = mysqli_real_escape_string($d,$_POST['adlt']);
    $Kids = mysqli_real_escape_string($d,$_POST['chld']);

    if($Adult < 6)

     {$q = "INSERT INTO booking_room(First_Name,Last_Name,Mobile_Number,CheckIn,CheckOut,Room_Type,Adults,Kids) VALUES('$fname','$lname','$Mobile','$checkin','$co','$Room','$Adult','$Kids')";
    mysqli_query($d,$q);
          
       header("Location: detailes.php");
  }   
else
{
  header("Location: index.php");
}
    //header("Location:detailes.php");


 }
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Booking Portal</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Rubik:300,400,500" rel="stylesheet">
    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/aos.css">
    <link rel="stylesheet" href="css/ionicons.min.css">
    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
           

          <form action = "#" method="POST">
                
                <fieldset>
                <legend> PERSONAL DETAILES:</legend>
                <center><label for = "name">First Name: </label><input type="text" name="F" id = "name" required autofocus placeholder="Your First Name" pattern="[a-zA-Z]{3,}" title="Enter Your First Name"></center>
                <center><label for = "lname">Last Name: </label><input type="text" name="L" id = "lname" required autofocus placeholder="Your Last Name" pattern="[a-zA-Z]{3,}" title="Enter Your Last Name"></center>
                <center><label for = "email">E-Mail: </label><input type="text" name="E" id = "email" required autofocus placeholder="Your E-Mail Address" pattern="[a-zA-Z]{3,}@[a-zA-Z]{3,}[.]{1}[a-z]{3,}" title="Enter Your E-Mail Address"></center>
                <center><label for = "phone">Mobile Number: </label><input type="tel" name="M" id = "phone" required autofocus placeholder="Your Mobile Number" pattern="[0-9]{10}" title="Enter Your Mobile Number"></center>
                <center><label for = "add">Address: </label><input type="text" name="A" id = "add" required autofocus placeholder="Your Address"  title="Enter Your Address"></center>
                <center><label for="county">COUNTRY: </label><select name="Country" required id="county">
                    
                            <option value=""> </option>
                            <option value="IND">INDIA</option>
                            <option value="US">USA</option>
                            <option value="UK">UK</option>
                            <option value="CHN">CHINA</option>
                            <option value="JPN">JAPAN</option>
                </select>
                                             </center>
            </fieldset>
            <fieldset>
                <legend>BOOKING DETAILES:</legend>
                 <center><label for = "checkin">Check-In: </label><input type="date" name="Ci" id = "checkin" required  placeholder="Check-In Date" title="Enter Your Check-In Date"></center>
                 <center><label for = "checkout">Check-Out: </label><input type="date" name="Co" id = "checkout" required  placeholder="Check-Out Date" title="Enter Your Check-Out Date"></center>
                 <center><label for="rtype">ROOM TYPE: </label><select name="RoomType" required id="rtype">
                    
                            <option value=""> </option>
                            <option value="BR">Bachelor Room</option>
                            <option value="FR">Family Room</option>
                            <option value="PR">Presidential Room</option>
                            <option value="DR">Double Room</option>
                            <option value="VR">VIP Room</option>
                </select>
                                             </center>
              
                                             </center>
               <center>
                   <label for = "ad"> NO. OF ADULTS:</label><input type="number" name="adlt" id="ad" required  min="1" max="6">
               </center>
               <center>
                   <label for = "cd"> NO. OF CHILDRENS:</label><input type="number" name="chld" id="cd" required  min="0" max="6" maxlength="100">
               </center>
            </fieldset>
            <br><br><br>
            <center><input type="submit" name="s0" value="Book"></center>
          </form>
</body>
</html>