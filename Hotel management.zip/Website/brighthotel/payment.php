<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Payment</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Rubik:300,400,500" rel="stylesheet">
    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/aos.css">
    <link rel="stylesheet" href="css/ionicons.min.css">
    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
  </head>
  <body>
     <form action="#" method="POST">
        <fieldset>
            <center><legend>PAYMENT DETAILES</legend></center>
             <center><label for="c">CARD TYPE: </label><select name="C" required id="c">
                    
                            <option value=""> </option>
                            <option value="CC">Credit Card</option>
                            <option value="DC">Debit Card</option>
                            
                </select>
                                             </center>
             <center><label for = "cn">CARD NUMBER: </label><input type="text" name="n" id = "cn" required autofocus placeholder="Your Card Number" pattern="[0-9]{4} [0-9]{4} [0-9]{4}" title="Enter Your Card Number"></center>

             <center><label for="ed">EXPIRY DATE: </label><select name="E" required id="ed">
                  
                                             </center>

            
        </fieldset>
         
     </form>
  </body>
  </html>