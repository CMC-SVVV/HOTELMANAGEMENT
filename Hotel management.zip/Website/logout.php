<?php
     session_start();
     session_destroy();
     unset($_SESSION['your_name']);
     $_SESSION['message'] = "You are now Logged Out";
     header("location:\website\index.php");
?>